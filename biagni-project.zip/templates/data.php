<?php

	$products = [
		"Anillos" => ["Goku Y Milk", 
					  "Hotel Transylvania", 
					  "Las Chicas Super Poderosas"],
		
		"Collar" => ["Dark",
					 "Pinguino",
					 "Rapunzel",
					 "Regalo Para Tu Novio",
					 "Stitch",
					 "Stitch 2",
					 "Taza De Café"],
		
		"Pulsera" => ["Cute", 
					  "Cute 2", 
					  "Cute 3", 
					  "Dr Strange"]
	];