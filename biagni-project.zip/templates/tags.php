<!--Importamos los documentos php-->
<?php require("templates/config.php"); ?>


