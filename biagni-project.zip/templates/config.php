<?php 

	$name_page = "&#x1f33b; Bisutería Girasoles ";
	$tags = ["Anillos", "Collar", "Pulsera"];